#include <iostream>
#include "ComputedPlayer.hpp"

int main()
{
	
}