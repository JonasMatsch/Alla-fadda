#include <iostream>
#include <stdio.h>
#include "Player.hpp"
#include "GameBoard.hpp"

class HumanPlayer : public Player
{
	public:
	int num;
	HumanPlayer(int num);
	void play(GameBoard& board);
};

void HumanPlayer::play(GameBoard& board){
		bool input = false;
		while(!input){
		std::cout << "Select a row:";
		int inputR;
		scanf("%i",&inputR);
		std::cout << "Select a column";
		int inputC;
		scanf("%i",&inputC);
		if(board.isFree(inputR,inputC))
		{
			input = true;
			std::cout << "Player " << num << ":" << inputR << "|" << inputC;
			board.board[inputR][inputC] = num;
		}
		else
		{
			printf("Invalid field selection");
		}
		}
	}