#include <iostream>

	enum Mode{
		RANDOM, MINIMAX
	};