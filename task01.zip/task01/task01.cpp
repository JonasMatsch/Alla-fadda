#include <iostream>
#include "GameMaster.hpp"

int main()
{
	GameMaster gm = GameMaster();
	gm.start();
}